# Probable Spork Operator Console

## Start Here - Quick Launch

**🚀 One Command to Start Everything:**
```bash
make op-console
```

This starts both the FastAPI backend and Gradio UI. You'll see:
- FastAPI API: http://127.0.0.1:8008
- Gradio UI: http://127.0.0.1:7860
- API docs: http://127.0.0.1:8008/docs

**🔑 Authentication:**
- Default admin token: `default-admin-token-change-me`
- Set `ADMIN_TOKEN` environment variable to override
- All API calls require `Authorization: Bearer <token>` header

## Individual Services

**Start just the API:**
```bash
make op-console-api
```

**Start just the UI:**
```bash
make op-console-ui
```

## First-Time Setup

1. **Install dependencies:**
   ```bash
   make install
   ```

2. **Set admin token (optional but recommended):**
   ```bash
   export ADMIN_TOKEN="your-secure-token-here"
   ```

3. **Launch console:**
   ```bash
   make op-console
   ```

## Smoke Test

**Validate your setup:**
```bash
./scripts/smoke_op_console.sh
```

This creates a test job, waits for approval, approves it, and verifies completion.

## Troubleshooting

**Port conflicts:**
- FastAPI default: 8008 (change in `conf/operator.yaml`)
- Gradio default: 7860 (change with `UI_PORT` env var)

**Token errors:**
- Check `ADMIN_TOKEN` environment variable
- Verify token in request headers: `Authorization: Bearer <token>`

**SSE blocked:**
- Use polling fallback: GET `/jobs/{id}/events?poll=true`
- Check browser console for connection errors

**Service won't start:**
- Check Python version (3.9-3.11 required)
- Verify virtual environment is activated
- Check logs for dependency errors

## Cleanup

**Remove operator console artifacts:**
```bash
make clean-op-console
```

This removes build artifacts without touching core pipeline files.

---

# Asset Loop Management

## Quick Start
```bash
# Run complete asset loop for a topic
make asset-loop SLUG=<slug>

# Or run individual steps
make asset-rebuild                    # Rebuild asset library manifest
make asset-plan SLUG=<slug>          # Create asset plan (resolves existing assets)
make asset-fill SLUG=<slug>          # Generate new assets to fill gaps
make asset-reflow SLUG=<slug>        # Reflow storyboard with concrete assets

# Run complete research pipeline for a topic
make research-reuse SLUG=<slug>      # Research using cached data only
make research-live SLUG=<slug>       # Research with live API calls (consumes quota)
make research-report SLUG=<slug>     # Generate research coverage report
```

## Individual CLI Commands
```bash
# Rebuild asset manifest
python bin/asset_manifest.py --rebuild

# Resolve assets for a topic
python bin/asset_librarian.py --slug <slug>

# Fill asset gaps
python bin/asset_generator.py --plan runs/<slug>/asset_plan.json

# Reflow storyboard
python bin/reflow_assets.py --slug <slug>

# Research pipeline commands
python bin/trending_intake.py --mode reuse|live --slug <slug>
python bin/research_collect.py --slug <slug> --mode reuse|live --max 50
python bin/research_ground.py --slug <slug> --mode reuse|live
python bin/fact_guard.py --slug <slug> --mode reuse|live
python bin/research_report.py --slug <slug> --compact
```

## Research Pipeline Management

### Research Modes
The research pipeline supports two modes to balance determinism with freshness:

- **Reuse Mode** (`--mode reuse`): Uses cached data only, produces identical results across runs
- **Live Mode** (`--mode live`): Makes API calls with rate limiting, updates cache for future reuse

### Complete Research Pipeline
```bash
# Run complete research pipeline in reuse mode (recommended for testing)
make research-reuse SLUG=eames-history

# Run complete research pipeline in live mode (consumes API quota)
make research-live SLUG=eames-history

# Generate research coverage report
make research-report SLUG=eames-history
```

### Individual Research Steps
```bash
# Trending topics intake (feeder only, non-citable)
python bin/trending_intake.py --mode reuse --slug eames-history

# Collect research content from sources
python bin/research_collect.py --slug eames-history --mode reuse --max 50

# Ground script content with research citations
python bin/research_ground.py --slug eames-history --mode reuse

# Fact-check and validate claims
python bin/fact_guard.py --slug eames-history --mode reuse

# Generate research coverage report
python bin/research_report.py --slug eames-history --compact
```

### Research Artifacts
Each research run creates artifacts under `data/<slug>/`:
- `grounded_beats.json` — script beats with inline citations
- `references.json` — normalized citation metadata
- `fact_guard_report.json` — claim validation results
- `trending_topics.json` — trending intake data (non-citable)

### Research Acceptance Gates
The research pipeline enforces quality gates:
- **Citation Coverage**: ≥60% of beats must have ≥1 citation
- **Average Citations**: ≥1.0 citations per beat on average
- **Fact-Guard Clean**: No unsupported claims after validation

## Style Presets & Texture Control

### Quick Preset Selection
Style presets provide operator control over texture parameters without editing configuration files:

```bash
# List available presets
python bin/texture_probe.py --help

# Generate probe grid with specific preset
python bin/texture_probe.py --slug <slug> --preset print-soft
python bin/texture_probe.py --slug <slug> --preset halftone_classic
python bin/texture_probe.py --slug <slug> --preset vintage_paper

# Use base configuration (no preset)
python bin/texture_probe.py --slug <slug>
```

### Available Style Presets
- **print-soft**: Subtle paper grain with minimal posterization
- **print-strong**: Bold paper texture with visible grain and posterization  
- **flat_noise**: Flat design with subtle noise overlay
- **halftone_classic**: Classic halftone dot pattern with moderate grain
- **vintage_paper**: Aged paper feel with heavy grain and posterization
- **minimal**: Clean, minimal texture with subtle edge softening
- **modern_flat**: Modern flat design with minimal texture
- **off**: No texture effects applied

### Texture Probe Tool
The probe tool generates a visual grid showing texture parameter combinations:
- **Input**: Representative test frame with various elements
- **Output**: `runs/<slug>/texture_probe_grid.png` showing grain × posterize × halftone combinations
- **Use case**: Preview texture effects before full render, compare preset styles

### Preset Configuration
Presets are defined in `conf/style_presets.yaml` and can be customized:
- Each preset maps to specific texture parameters
- Presets override base configuration from `conf/global.yaml`
- Changes are logged with preset name and resolved parameters

## Pacing KPI & Feedback Management

### Quick Pacing Analysis
The pacing system provides operator commands to analyze and tune video pacing metrics:

```bash
# Compute pacing KPIs and generate report
make pacing-report SLUG=<slug>

# Apply feedback adjustments and update metadata
make pacing-tune SLUG=<slug>

# Run smoke test (KPI → feedback dry-run → summary)
make pacing-smoke SLUG=<slug>
```

### Individual CLI Commands
```bash
# Compute pacing KPIs
python bin/pacing_kpi.py --slug <slug>

# Show proposed adjustments without applying
python bin/pacing_feedback.py --slug <slug> --dry-run

# Apply adjustments and update metadata
python bin/pacing_feedback.py --slug <slug> --apply
```

### Pacing Metrics
The system computes four key pacing metrics:
- **Words/sec**: Total words / total speech duration (from SRT if available, else brief-based)
- **Cuts/min**: Scene transitions per minute
- **Avg scene**: Mean scene duration in seconds
- **Speech/music ratio**: Speech duration / (total - speech duration)

### Feedback Adjustment
The feedback system provides one-pass deterministic adjustments:
- **Safety bounds**: ±0.5–1.0s max per scene, respects timing clamps
- **VO alignment**: If `timing.align_to_vo=true`, visual timing conforms to VO windows
- **Deterministic**: Same inputs produce identical adjustments
- **Idempotent**: Only one feedback iteration per run

### Pacing Bands
Metrics are compared against intent-specific bands from `conf/intent_profiles.yaml`:
- **Within band**: No adjustments needed
- **>10% out of band**: Single feedback pass attempted
- **Still out after feedback**: WARN (non-strict) or FAIL (strict) per config

### Pacing Artifacts
Each pacing run creates artifacts under `runs/<slug>/`:
- `pacing_report.json` — raw metrics + per-scene durations + flags before/after feedback
- `pacing_adjustments.json` — exact adjustments proposed/applied
- Updated `videos/<slug>.metadata.json` with pacing block

### Pacing Acceptance Gates
The pacing system enforces quality gates:
- **KPI computation**: All metrics computed and stored in metadata
- **Band compliance**: Metrics within ±10% of target bands after feedback
- **No regressions**: No layout collisions or contrast issues introduced
- **Audit trail**: All adjustments logged with before/after values

## Artifacts Generated
Each run creates artifacts under `runs/<slug>/`:
- `asset_plan.json` — resolved assets & gaps list
- `asset_generation_report.json` — new assets with parameters, seeds, palette
- `reflow_summary.json` — bounding boxes before/after, QA results
- `<slug>_reflowed.json` — updated scenescript with concrete assets
- `texture_probe_grid.png` — texture parameter comparison grid (when using probe tool)

## Logging
All commands use structured logging with stage tags:
- `[manifest]` — Asset manifest operations
- `[librarian]` — Asset resolution and planning
- `[generator]` — Asset generation and gap-filling
- `[reflow]` — Storyboard reflow and QA
- `[texture_probe]` — Texture probe and preset operations
- `[trending]` — Trending topics intake operations
- `[collect]` — Research content collection
- `[ground]` — Research grounding and citations
- `[fact-guard]` — Fact-checking and validation
- `[citations]` — Citation processing and metadata
- `[research_report]` — Research coverage reporting
- `[pacing-kpi]` — Pacing KPI computation and analysis
- `[pacing-compare]` — Pacing comparison against intent bands
- `[pacing-feedback]` — Pacing feedback adjustment operations
- `[pacing-accept]` — Pacing acceptance gate validation

## Success Criteria
- **Coverage:** 100% of storyboard placeholders resolved to concrete assets
- **Reuse ratio:** ≥70% of assets are reused when a library exists
- **QA clean:** No collisions after reflow; safe margins respected
- **Metadata:** Video metadata updated with asset coverage information
- **Texture control:** Operators can quickly preview and select texture styles via presets

## Example: Eames Topic with Style Presets
```bash
# Generate probe grid with vintage paper preset
python bin/texture_probe.py --slug eames --preset vintage_paper

# This demonstrates:
# - Style preset resolution and parameter merging
# - Visual texture parameter exploration
# - Preset metadata logging (description, resolved params)
# - Probe grid generation for operator review
```

## Example: Eames Topic
```bash
make asset-loop SLUG=eames
```
This demonstrates:
- 100% asset reuse (5/5 assets resolved from existing library)
- No gaps requiring generation
- All QA checks passing (0 collisions, 0 margin violations)
- Clean artifacts generated in `runs/eames/`
