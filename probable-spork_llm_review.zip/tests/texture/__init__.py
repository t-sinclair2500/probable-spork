# Texture and visual processing tests
